#define _ITERATOR_DEBUG_LEVEL 0
#include <math.h>
#include <algorithm> 
#include "ArrayUtilities.h"

namespace ArrayUtilities
{
	uint8_t* AddArrays(uint8_t* array1, long length, uint8_t* array2)
	{
		for (int i = 0; i < length; i++)
		{
			array2[i] += array1[i];
		}

		return array2;
	}

	uint8_t* SubArrays(uint8_t* array1, long length, uint8_t* array2)
	{
		double angle1, angle2, distance1, distance2, resultDistance;
		
		for (int i = 0; i < length; i++)
		{		
			if (i % 2 == 0)
			{
				array2[i] = array1[i] - array2[i];
			}
			else
			{
				angle1 = array1[i];
				angle2 = array2[i];

				if (angle1 < angle2)
				{
					distance1 = angle1 + (255 - angle2);
					distance2 = angle2 - angle1;

					resultDistance = std::min(distance1, distance2);
				}
				else if (angle2 < angle1)
				{
					distance1 = angle2 + (255 - angle1);
					distance2 = angle1 - angle2;

					resultDistance = std::min(distance1, distance2);
				}
				else
					resultDistance = 0;

				array2[i] = resultDistance;
			}

		}

		return array2;
	}

	fftw_complex* AddArrays(fftw_complex* array1, long length, fftw_complex* array2)
	{
		for (int i = 0; i < length; i++)
		{
			array2[i][0] += array1[i][0];
			array2[i][1] += array1[i][1];
		}

		return array2;
	}

	uint32_t* AddToArray(uint32_t* array, uint32_t value, uint32_t length)
	{
		for (int i = 0; i < length; i++)
		{
			array[i] += value;
		}

		return array;
	}

	double* DivideArray(double* array1, long length, double divisor)
	{
		for (int i = 0; i < length; i++)
		{
			array1[i] /= divisor;			
		}

		return array1;
	}


	fftw_complex* DivideArray(fftw_complex* array1, long length, double divisor)
	{
		for (int i = 0; i < length; i++)
		{
			array1[i][0] /= divisor;
			array1[i][1] /= divisor;
		}

		return array1;
	}

	fftw_complex* DivideArray(fftw_complex* array1, long length, fftw_complex* array2)
	{
		for (int i = 0; i < length; i++)
		{
			array1[i][0] /= array2[i][0];
			array1[i][1] /= array2[i][0];
		}

		return array1;
	}


	uint8_t* CopyArray(uint8_t* array1, long length, uint8_t* array2)
	{
		for (int i = 0; i < length; i++)
		{
			array2[i] = array1[i];
		}

		return array2;
	}

	double* CopyArray(uint8_t* array1, long length, double* array2)
	{
		for (int i = 0; i < length; i++)
		{
			array2[i] = array1[i];
		}

		return array2;
	}

	fftw_complex* CopyArray(fftw_complex* array1, long length, fftw_complex* array2)
	{
		for (int i = 0; i < length; i++)
		{
			array2[i][0] = array1[i][0];
			array2[i][1] = array1[i][1];
		}

		return array2;
	}

	double* CopyArray(fftw_complex* array1, long length, double* array2)
	{
		for (int i = 0; i < length; i++)
		{
			array2[i * 2] = array1[i][0];
			array2[i * 2 + 1] = array1[i][1];
		}

		return array2;
	}

	double GetAverage(fftw_complex* dataArray, uint32_t length, bool forRealValue, bool forImaginaryValue)
	{
		double total = 0;

		for (int i = 0; i < length; i++)
		{
			if (forRealValue && forImaginaryValue)
			{
				total += dataArray[i][0]/2 + dataArray[i][1]/2;
			}
			else
			{
				if (!forRealValue && !forImaginaryValue)
				{
					total += (float)sqrt(dataArray[i][0] * dataArray[i][0] + dataArray[i][1] * dataArray[i][1]);
				}
				else if (forRealValue)
					total += dataArray[i][0];
				else if (forImaginaryValue)
					total += dataArray[i][1];
			}			
		}
		
		return total / length;
	}

	/*////
	double* GetMinValueAndIndex(fftw_complex* dataArray, uint32_t length, bool forRealValue, bool forImaginaryValue)
	{
		int minIndex = -1;

		double minValue = 0, value = 0;

		for (int i = 0; i < length; i++)
		{
			if (forRealValue && forImaginaryValue)
			{
				value = std::min(dataArray[i][0], dataArray[i][1]);
			}
			else
			{
				if (!forRealValue && !forImaginaryValue)
				{
					value = (float)sqrt(dataArray[i][0] * dataArray[i][0] + dataArray[i][1] * dataArray[i][1]);
				}
				else if (forRealValue)
					value = dataArray[i][0];
				else if (forImaginaryValue)
					value = dataArray[i][1];
			}

			if (i == 0 || value < minValue)
			{
				minIndex = i;
				minValue = value;
			}
		}


		double *result = new double[2];

		result[0] = minIndex;
		result[1] = minValue;

		return result;
	}*/

	double* GetMinValueAndIndex(fftw_complex* dataArray, uint32_t length, bool forRealValue, bool forImaginaryValue, bool absolute)
	{
		int minIndex = -1;

		double minValue = 0, value = 0;

		for (int i = 0; i < length; i++)
		{
			if (forRealValue && forImaginaryValue)
			{
				if (!absolute)
					value = std::min(dataArray[i][0], dataArray[i][1]);
				else
					value = std::min(abs(dataArray[i][0]), abs(dataArray[i][1]));

			}
			else
			{
				if (!forRealValue && !forImaginaryValue)
				{
					value = (float)sqrt(dataArray[i][0] * dataArray[i][0] + dataArray[i][1] * dataArray[i][1]);
				}
				else if (forRealValue)
				{
					if (!absolute)
						value = dataArray[i][0];
					else
						value = abs(dataArray[i][0]);
				}
				else if (forImaginaryValue)
				{
					if (!absolute)
						value = dataArray[i][1];
					else
						value = abs(dataArray[i][1]);
				}
			}

			if (i == 0 || value < minValue)
			{
				minIndex = i;
				minValue = value;
			}
		}

		double *result = new double[2];

		result[0] = minIndex;
		result[1] = minValue;

		return result;
	}

	double* GetMaxValueAndIndex(fftw_complex* dataArray, uint32_t length, bool forRealValue, bool forImaginaryValue, bool absolute)
	{
		int maxIndex = -1;

		double maxValue = 0, value = 0;
		
		for (int i = 0; i < length; i++)
		{
			if (forRealValue && forImaginaryValue)
			{				
				if (!absolute)
					value = std::max(dataArray[i][0], dataArray[i][1]);
				else
					value = std::max(abs(dataArray[i][0]), abs(dataArray[i][1]));

			}
			else
			{
				if (!forRealValue && !forImaginaryValue)
				{					
					value = (float) sqrt(dataArray[i][0] * dataArray[i][0] + dataArray[i][1] * dataArray[i][1]);
				}
				else if (forRealValue)
				{
					if (!absolute)
						value = dataArray[i][0];
					else
						value = abs(dataArray[i][0]);
				}
				else if (forImaginaryValue)
				{
					if (!absolute)
						value = dataArray[i][1];
					else
						value = abs(dataArray[i][1]);
				}
			}

			if (i == 0 || value > maxValue)
			{
				maxIndex = i;
				maxValue = value;
			}
		}

		double *result = new double[2];

		result[0] = maxIndex;		
		result[1] = maxValue;
		
		return result;
	}

	VectorPtr* ResizeArray(VectorPtr* array, uint32_t prevSize, uint32_t newSize)
	{
		VectorPtr* newArray = new VectorPtr[newSize];

		memcpy(newArray, array, prevSize * sizeof(VectorPtr));

		for (int i = prevSize; i < newSize; i++)
		{
			newArray[i] = NULL;
		}

		delete[] array;

		array = newArray;

		return array;
	}

	void ZeroArray(uint32_t* array, uint32_t startIndex, uint32_t endIndex)
	{
		for (int i = startIndex; i < endIndex; i++)
		{
			array[i] = 0;			
		}
	}

	void ZeroArray(fftw_complex* array, uint32_t startIndex, uint32_t endIndex)
	{
		for (int i = startIndex; i < endIndex; i++)
		{
			array[i][0] = 0;
			array[i][1] = 0;
		}		
	}

}