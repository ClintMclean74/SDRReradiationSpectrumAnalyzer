#pragma once
#include "Graph.h"

class SelectedGraph
{
	public:
		Graph* graph;
		glm::vec4 point;

		SelectedGraph()
		{
			graph = NULL;
		}
};

class Graphs
{
	GraphPtr* graphs = NULL;
	uint32_t graphCount = 0;

	uint32_t bufferSize = 3;

	public:
		Graphs();
		uint32_t AddGraph(Graph* graph);
		void Draw();		
		SelectedGraph GetSelectedGraph(float x, float y, float z);
		
		~Graphs();
};


