#pragma once

namespace DebuggingUtilities
{
	static const bool DEBUGGING = false;

	void DebugPrint(const char * format, ...);
}