#include "SpectrumAnalyzer.h"
#include <process.h>

SpectrumAnalyzer::SpectrumAnalyzer()
{	
}

uint8_t SpectrumAnalyzer::InitializeSpectrumAnalyzer(uint32_t bufferSizeInMilliSeconds, uint32_t sampleRate, uint32_t minStartFrequency, uint32_t maxEndFrequency)
{
	/*////
	x = &SpectrumAnalyzer::StartReceivingData;

	(this->*(this->x))();
	*/

	maxFrequencyRange.Set(minStartFrequency, maxEndFrequency);

	deviceReceivers = new DeviceReceivers(this, bufferSizeInMilliSeconds, sampleRate);

	deviceReceivers->InitializeDevices();

	fftSpectrumBuffers = new FFTSpectrumBuffers(minStartFrequency, maxEndFrequency, 4, deviceReceivers->count);	

	return deviceReceivers->initializedDevices;
}

void SpectrumAnalyzer::SetCurrentCenterFrequency(uint32_t centerFrequency)
{
	deviceReceivers->SetCurrentCenterFrequency(centerFrequency);
}

void SpectrumAnalyzer::SetRequiredFramesPerBandwidthScan(uint32_t frames)
{
	requiredFramesPerBandwidthScan = frames;	
}

void SpectrumAnalyzer::SetRequiredScanningSequences(uint32_t frames)
{
	requiredScanningSequences = frames;
}

void SpectrumAnalyzer::SetCalculateFFTDifferenceBuffer(bool value)
{
	calculateFFTDifferenceBuffer = value;
}

void SpectrumAnalyzer::StartReceivingData()
{		
	SetCurrentCenterFrequency(fftSpectrumBuffers->frequencyRange.lower + DeviceReceiver::SAMPLE_RATE/2);

	deviceReceivers->StartReceivingData();

	////deviceReceivers->Synchronize();
}

void ScanFrequencyRangeThread(void *param)
{
	SpectrumAnalyzer* spectrumAnalyzer = (SpectrumAnalyzer*)param;

	spectrumAnalyzer->Scan();
	
	_endthread();
}

void SpectrumAnalyzer::Scan()
{
	FrequencyRange currentBandwidthRange;

	while (scanning)
	{
		/*////if (synchronizedCount<10000)
			deviceReceivers->Synchronize();			

		synchronizedCount++;
		*/

		for (int j = 0; j < requiredScanningSequences; j++)
		{
			currentBandwidthRange.Set(currentScanningFrequencyRange.lower, currentScanningFrequencyRange.lower + DeviceReceiver::SAMPLE_RATE);

			do
			{
				deviceReceivers->SetCurrentCenterFrequency(currentBandwidthRange.centerFrequency);

				/*////for (int i = 0; i < requiredFramesPerBandwidthScan; i++)
				{					
					deviceReceivers->TransferDataToFFTSpectrumBuffer(fftSpectrumBuffers, currentFFTBufferIndex);					
				}

				if (calculateFFTDifferenceBuffer)
					fftSpectrumBuffers->CalculateFFTDifferenceBuffer(0, 1);
					*/

				currentBandwidthRange.Set(currentBandwidthRange.lower + DeviceReceiver::SAMPLE_RATE, currentBandwidthRange.upper + DeviceReceiver::SAMPLE_RATE);
			} while (currentBandwidthRange.lower < currentScanningFrequencyRange.upper);
		}				

		sequenceFinishedFunction();		
	}
}

void SpectrumAnalyzer::SetSequenceFinishedFunction(void(*func)())
{
	sequenceFinishedFunction = func;	
}

void SpectrumAnalyzer::LaunchScanningFrequencyRange(FrequencyRange frequencyRange)
{
	currentScanningFrequencyRange = frequencyRange;
	scanning = true;

	scanFrequencyRangeThreadHandle = (HANDLE)_beginthread(ScanFrequencyRangeThread, 0, this);
}

bool SpectrumAnalyzer::SetFFTInput(fftw_complex* fftBuffer, FrequencyRange* inputFrequencyRange, uint8_t* samples, uint32_t sampleCount, uint8_t deviceID)
{	
	return fftSpectrumBuffers->SetFFTInput(currentFFTBufferIndex, fftBuffer, samples, sampleCount, deviceID, inputFrequencyRange, deviceID == 0);
}

bool SpectrumAnalyzer::ProcessReceiverData(FrequencyRange* inputFrequencyRange, bool useRatios)
{	
	/*////if (!deviceReceivers->Synchronized())
	{		
		deviceReceivers->Synchronize(GetFFTSpectrumBuffer(currentFFTBufferIndex)->GetSampleDataForDevice(0), GetFFTSpectrumBuffer(currentFFTBufferIndex)->GetSampleDataForDevice(1));
	}*/

	return fftSpectrumBuffers->ProcessFFTInput(currentFFTBufferIndex, inputFrequencyRange, useRatios);
}

FFTSpectrumBuffer* SpectrumAnalyzer::GetFFTSpectrumBuffer(int fftSpectrumBufferIndex)
{
	return fftSpectrumBuffers->GetFFTSpectrumBuffer(fftSpectrumBufferIndex);	
}

uint32_t SpectrumAnalyzer::GetDataForDevice(uint8_t *dataBuffer, uint8_t deviceIndex)
{
	return deviceReceivers->GetDataForDevice(dataBuffer, deviceIndex);
}

uint32_t SpectrumAnalyzer::GetDataForDevice(double *dataBuffer, uint8_t deviceIndex)
{
	return deviceReceivers->GetDataForDevice(dataBuffer, deviceIndex);
}

uint32_t SpectrumAnalyzer::GetFFTData(double *dataBuffer, unsigned int dataBufferLength, int fftSpectrumBufferIndex, int startFrequency, int endFrequency, uint8_t dataMode)
{
	FFTSpectrumBuffer* fftBuffer = fftSpectrumBuffers->GetFFTSpectrumBuffer(fftSpectrumBufferIndex);

	if (fftBuffer)
		return fftBuffer->GetFFTData(dataBuffer, dataBufferLength, startFrequency, endFrequency, dataMode);
	else
		return NULL;
}

uint32_t SpectrumAnalyzer::GetBinCountForFrequencyRange()
{
	return fftSpectrumBuffers->GetBinCountForFrequencyRange();
}

uint32_t SpectrumAnalyzer::GetFrameCountForRange(uint8_t fftSpectrumBufferIndex, uint32_t startFrequency, uint32_t endFrequency)
{
	return fftSpectrumBuffers->GetFFTSpectrumBuffer(fftSpectrumBufferIndex)->GetFrameCountForRange(startFrequency, endFrequency);
}

void SpectrumAnalyzer::GetDeviceCurrentFrequencyRange(uint32_t deviceIndex, uint32_t* startFrequency, uint32_t* endFrequency)
{
	deviceReceivers->GetDeviceCurrentFrequencyRange(deviceIndex, startFrequency, endFrequency);
}

void SpectrumAnalyzer::GetCurrentScanningRange(uint32_t* startFrequency, uint32_t* endFrequency)
{
	*startFrequency = currentScanningFrequencyRange.lower;
	*endFrequency = currentScanningFrequencyRange.upper;
}

double SpectrumAnalyzer::GetStrengthForRange(uint32_t fftSpectrumBufferIndex, uint32_t startFrequency, uint32_t endFrequency, uint8_t dataMode)
{
	return fftSpectrumBuffers->GetFFTSpectrumBuffer(fftSpectrumBufferIndex)->GetStrengthForRange(startFrequency, endFrequency, dataMode);
}

SpectrumAnalyzer::~SpectrumAnalyzer()
{
	scanning = false;

	requiredScanningSequences = 0;
	requiredFramesPerBandwidthScan = 0;

	Sleep(2000);
}
