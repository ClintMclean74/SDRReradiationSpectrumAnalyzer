#define _ITERATOR_DEBUG_LEVEL 0
#include <string>
#include <process.h>
#include "SpectrumAnalyzer.h"
#include "DeviceReceivers.h"
#include "DeviceReceiver.h"
#include "convenience.h"
#include "SignalProcessingUtilities.h"
#include "kerberos_functions.h"
#include "NearFarDataAnalyzer.h"
#include "DebuggingUtilities.h"


const double M_PI = 3.14159265358979323846;

DeviceReceiver::DeviceReceiver(void* parent, long bufferSizeInMilliSeconds, uint32_t sampleRate, uint8_t ID)
{
	this->parent = parent;
	this->deviceID = ID;	

	SAMPLE_RATE = 1000000;
	
	RECEIVE_BUFF_LENGTH = SignalProcessingUtilities::ClosestIntegerMultiple(SAMPLE_RATE * 2, 16384);
	RECEIVE_BUFF_LENGTH = FFT_SEGMENT_BUFF_LENGTH * 2;

	////RECEIVE_BUFF_LENGTH = 200;

	if (RECEIVE_BUFF_LENGTH < FFT_SEGMENT_BUFF_LENGTH)
		FFT_SEGMENT_BUFF_LENGTH = RECEIVE_BUFF_LENGTH;

	////FFT_SEGMENT_BUFF_LENGTH = RECEIVE_BUFF_LENGTH;

	CORRELATION_BUFF_LENGTH = FFT_SEGMENT_BUFF_LENGTH * 2;
	FFT_SEGMENT_SAMPLE_COUNT = FFT_SEGMENT_BUFF_LENGTH / 2;

	/*////
	receiveDataGate = CreateSemaphore(
		NULL,           // default security attributes
		0,  // initial count
		100,  // maximum count
		NULL);          // unnamed semaphore

	if (receiveDataGate == NULL)
	{
		DebuggingUtilities::DebugPrint("CreateSemaphore error: %d\n", GetLastError());
	}*/

	rtlDataAvailableGate = CreateSemaphore(
			NULL,           // default security attributes
			0,  // initial count
			10,  // maximum count
			NULL);          // unnamed semaphore

	if (rtlDataAvailableGate == NULL)
	{
		if (DebuggingUtilities::DEBUGGING)
		{
			DebuggingUtilities::DebugPrint("CreateSemaphore error: %d\n", GetLastError());			
		}
	}

	receiverBufferDataAvailableGate = CreateSemaphore(
		NULL,           // default security attributes
		0,  // initial count
		10,  // maximum count
		NULL);          // unnamed semaphore

	if (receiverBufferDataAvailableGate == NULL)
	{
		if (DebuggingUtilities::DEBUGGING)
		{
			DebuggingUtilities::DebugPrint("CreateSemaphore error: %d\n", GetLastError());
			
		}
	}
		
	circularDataBuffer = new CircularDataBuffer((float) bufferSizeInMilliSeconds / 1000 * sampleRate * 2, FFT_SEGMENT_BUFF_LENGTH);

	devicesToSendClonedDataTo = new DeviceReceiverPtr[4];
	devicesToSendClonedDataToCount = 0;

	transferDataBuffer = new uint8_t[RECEIVE_BUFF_LENGTH];
}

int DeviceReceiver::InitializeDeviceReceiver(int dev_index)
{
	int result = -1;

	result = rtlsdr_open(&device, dev_index);

	if (result < 0)
	{
		fprintf(stderr, "Failed to open rtlsdr device #%d.\n", dev_index);

		return result;
	}

	if (rtlsdr_set_dithering(device, 0) != 0) // Only in keenerd's driver
	{
		fprintf(stderr, "[ ERROR ] Failed to disable dithering: %s\n", strerror(errno));
	}

	if (rtlsdr_set_tuner_gain_mode(device, 1) != 0)
	{
		fprintf(stderr, "[ ERROR ] Failed to disable AGC: %s\n", strerror(errno));
	}

	if (rtlsdr_reset_buffer(device) != 0)
	{
		fprintf(stderr, "[ ERROR ] Failed to reset receiver buffer: %s\n", strerror(errno));
	}

	if (rtlsdr_set_tuner_gain(device, 1000) != 0)
	{
		fprintf(stderr, "[ ERROR ] Failed to set gain value: %s\n", strerror(errno));
	}

	rtlsdr_set_center_freq(device, 96000000);

	if (rtlsdr_set_sample_rate(device, SAMPLE_RATE) != 0)
	{
		fprintf(stderr, "[ ERROR ] Failed to set sample rate: %s\n", strerror(errno));
	}

	return dev_index;
}

void DeviceReceiver::SetFrequencyRange(FrequencyRange* frequencyRange)
{
	this->frequencyRange = frequencyRange;
	
	rtlsdr_set_center_freq(device, frequencyRange->centerFrequency);
}

void DeviceReceiver::FFT_BYTES(uint8_t *data, fftw_complex *fftData, int samples, bool inverse, bool inputComplex, bool rotate180)
{	
	unsigned int measure = FFTW_MEASURE;
	////unsigned int measure = FFTW_ESTIMATE;

	int j = 0;

	////inverse = true;

	DeviceReceivers* deviceReceivers = (DeviceReceivers*)parent;

	if (inputComplex)
	{
		if (complexArray == NULL && samples == DeviceReceiver::FFT_SEGMENT_SAMPLE_COUNT)
		{
			complexArray = (fftw_complex *)fftw_malloc(sizeof(fftw_complex) * samples);
		}
		else
		if (complexArray2 == NULL && samples == DeviceReceiver::FFT_SEGMENT_SAMPLE_COUNT * 2)
		{
			complexArray2 = (fftw_complex *)fftw_malloc(sizeof(fftw_complex) * samples);
		}
		else
			if (complexArray == NULL)
				complexArray = (fftw_complex *)fftw_malloc(sizeof(fftw_complex) * samples);
	}
	else
	{
		unsigned int fftSize = (samples * 2 + 1);
	}

	if (inputComplex)
	{

		if (deviceReceivers->complexArrayFFTPlan == NULL && samples == DeviceReceiver::FFT_SEGMENT_SAMPLE_COUNT)
		////if (samples == DeviceReceiver::FFT_SEGMENT_SAMPLE_COUNT)
		{
			if (referenceDevice)
			{
				deviceReceivers->complexArrayFFTPlan = fftw_plan_dft_1d(samples,
					complexArray,
					fftData,
					inverse ? FFTW_BACKWARD : FFTW_FORWARD,
					measure);

				if (ReleaseSemaphore(deviceReceivers->receiverGates[0], 1, NULL)==0)
				{
					DebuggingUtilities::DebugPrint("ReleaseSemaphore error: %d\n", GetLastError());
					
				}
			}
			else
				WaitForSingleObject(deviceReceivers->receiverGates[0], 10000000);
		}
		else
		if (deviceReceivers->complexArrayFFTPlan2 == NULL && samples == DeviceReceiver::FFT_SEGMENT_SAMPLE_COUNT * 2)
		////if (samples == DeviceReceiver::FFT_SEGMENT_SAMPLE_COUNT * 2)
		{
			if (referenceDevice)
			{
				deviceReceivers->complexArrayFFTPlan2 = fftw_plan_dft_1d(samples,
					complexArray2,
					fftData,
					inverse ? FFTW_BACKWARD : FFTW_FORWARD,
					measure);

				if (ReleaseSemaphore(deviceReceivers->receiverGates[0], 1, NULL)==0)
				{
					DebuggingUtilities::DebugPrint("ReleaseSemaphore error: %d\n", GetLastError());
					
				}
			}
			else
			{
				int grc = 1;

				WaitForSingleObject(deviceReceivers->receiverGates[0], 10000000);
			}
		}
		else if (deviceReceivers->complexArrayFFTPlan == NULL && samples != DeviceReceiver::FFT_SEGMENT_SAMPLE_COUNT && samples != DeviceReceiver::FFT_SEGMENT_SAMPLE_COUNT * 2)
		{
			if (referenceDevice)
			{
				deviceReceivers->complexArrayFFTPlan = fftw_plan_dft_1d(samples,
					complexArray,
					fftData,
					inverse ? FFTW_BACKWARD : FFTW_FORWARD,
					measure);

				if (ReleaseSemaphore(deviceReceivers->receiverGates[0], 1, NULL)==0)
				{
					DebuggingUtilities::DebugPrint("ReleaseSemaphore error: %d\n", GetLastError());
					
				}
			}
			else
			{
				int grc = 1;

				WaitForSingleObject(deviceReceivers->receiverGates[0], 10000000);
			}
		}

		j = 0;

		fftw_complex *array;

		if (samples == DeviceReceiver::FFT_SEGMENT_SAMPLE_COUNT)
		{
			array = complexArray;			
		}
		else
			if (samples == DeviceReceiver::FFT_SEGMENT_SAMPLE_COUNT * 2)
			{
				array = complexArray2;
			}
			else
				array = complexArray;

		for (int i = 0; i < samples; i++)
		{
			array[j][0] = (double)data[(int)i * 2] / 255 - 0.5;
			array[j][1] = (double)data[(int)i * 2 + 1] / 255 - 0.5;

			j++;
		}

		if (samples == DeviceReceiver::FFT_SEGMENT_SAMPLE_COUNT)
			fftw_execute_dft(deviceReceivers->complexArrayFFTPlan, array, fftData);
		else
			if (samples == DeviceReceiver::FFT_SEGMENT_SAMPLE_COUNT * 2)
				fftw_execute_dft(deviceReceivers->complexArrayFFTPlan2, array, fftData);
			else
				fftw_execute_dft(deviceReceivers->complexArrayFFTPlan, array, fftData);
	}
	
	if (rotate180)
	{
		int length2 = samples / 2;
		fftw_complex temp;

		fftData[0][0] = fftData[1][0];
		fftData[0][1] = fftData[1][1];

		for (int i = 0; i < length2; i++)
		{
			temp[0] = fftData[i][0];
			temp[1] = fftData[i][1];

			fftData[i][0] = fftData[i + length2][0];
			fftData[i][1] = fftData[i + length2][1];

			fftData[i + length2][0] = temp[0];
			fftData[i + length2][1] = temp[1];
		}
	}
}






void DeviceReceiver::FFT_COMPLEX_ARRAY(fftw_complex* data, fftw_complex* fftData, int samples, bool inverse, bool rotate180)
{	
	unsigned int measure = FFTW_MEASURE;
	////unsigned int measure = FFTW_ESTIMATE;

	DeviceReceivers* deviceReceivers = (DeviceReceivers*)parent;

	if (deviceReceivers->complexArrayCorrelationFFTPlan == NULL)
	{
		if (referenceDevice)
		{			
			fftw_complex* initializationData = (fftw_complex *)fftw_malloc(sizeof(fftw_complex) * samples);
			memcpy(initializationData, data, sizeof(fftw_complex) * samples);

			deviceReceivers->complexArrayCorrelationFFTPlan = fftw_plan_dft_1d(samples,
				initializationData,
				fftData,
				inverse ? FFTW_BACKWARD : FFTW_FORWARD,
				measure);

			fftw_free(initializationData);

			if (ReleaseSemaphore(deviceReceivers->receiverGates[0], 1, NULL)==0)
			{
				DebuggingUtilities::DebugPrint("ReleaseSemaphore error: %d\n", GetLastError());
				
			}
		}
		else
			WaitForSingleObject(deviceReceivers->receiverGates[0], 10000000);
	}

	/*////deviceReceivers->complexArrayFFTPlan2 = fftw_plan_dft_1d(samples,
		data,
		fftData,
		inverse ? FFTW_BACKWARD : FFTW_FORWARD,
		measure);
		*/


	fftw_execute_dft(deviceReceivers->complexArrayCorrelationFFTPlan, data, fftData);
	
	if (rotate180)
	{
		int length2 = samples / 2;
		fftw_complex temp;

		fftData[0][0] = fftData[1][0];
		fftData[0][1] = fftData[1][1];

		for (int i = 0; i < length2; i++)
		{
			temp[0] = fftData[i][0];
			temp[1] = fftData[i][1];

			fftData[i][0] = fftData[i + length2][0];
			fftData[i][1] = fftData[i + length2][1];

			fftData[i + length2][0] = temp[0];
			fftData[i + length2][1] = temp[1];
		}
	}
}


void DeviceReceiver::GenerateNoise(uint8_t state)
{
	if (state == 1)
		rtlsdr_set_gpio(device, 1, 0);
	else
		rtlsdr_set_gpio(device, 0, 0);	
}

void DeviceReceiver::WriteReceivedDataToBuffer(uint8_t *data, uint32_t length)
{
	DWORD currentTime = GetTickCount();
	DWORD startTime = currentTime;

	if (DeviceReceivers::TEST_CORRELATION && referenceDevice)
	{
		/*////for (int i = 0; i < receivedLength; i++)
		receivedBuffer[i] = ((float)rand() / RAND_MAX) * 255;
		*/

		if (receivedLength == RECEIVE_BUFF_LENGTH)
		{			
			////memcpy(transferDataBuffer, &receivedBuffer[4], receivedLength - 4);
			memcpy(&transferDataBuffer[4], receivedBuffer, receivedLength - 4);
			////memcpy(transferDataBuffer, receivedBuffer, receivedLength);		
		}
		else
		{
			int grc = 1;
		}
	}

	circularDataBuffer->WriteData(receivedBuffer, receivedLength);

	for (int i = 0; i < devicesToSendClonedDataToCount; i++)
		devicesToSendClonedDataTo[i]->ReceiveData(transferDataBuffer, receivedLength);

	if (ReleaseSemaphore(receiverBufferDataAvailableGate, 1, NULL)==0)
	{
		if (DebuggingUtilities::DEBUGGING)
		{
			DebuggingUtilities::DebugPrint("ReleaseSemaphore error: %d\n", GetLastError());			
		}
	}

	if (DebuggingUtilities::DEBUGGING)
	{
		DebuggingUtilities::DebugPrint("open receiverBufferDataAvailableGate\n");
		
	}

}

void DeviceReceiver::ProcessData(uint8_t *data, uint32_t length)
{				
	DWORD currentTime;

	if (fftBuffer == NULL)
		fftBuffer = new fftw_complex[FFT_SEGMENT_SAMPLE_COUNT];

	uint32_t segments, segmentBufferLength;
	
	if (length < DeviceReceiver::FFT_SEGMENT_BUFF_LENGTH)
	{
		segments = 1;

		segmentBufferLength = length;
	}
	else
	{
		segments = length / DeviceReceiver::FFT_SEGMENT_BUFF_LENGTH;

		segmentBufferLength = DeviceReceiver::FFT_SEGMENT_BUFF_LENGTH;
	}

	uint32_t samplesCount = segmentBufferLength / 2;		

	uint32_t currentSegmentIndex = 0;

	/////uint32_t currentSegmentIndex = delayShift;

	////SignalProcessingUtilities::Rotate(data, length, -phaseShift);

	////fftw_complex* fftBuffer = new fftw_complex[DeviceReceiver::FFT_SEGMENT_SAMPLE_COUNT];
	
	int i;

	DWORD dwWaitResult;
	DeviceReceivers* deviceReceivers = (DeviceReceivers*)parent;

	int32_t remainingTime = (int32_t)receivedDuration[receivedCount - 1] - (GetTickCount() - startTime);

	double segmentTime = (double)remainingTime / segments;
	DWORD startSegmentTime, segmentDuration;
	int32_t delay;

	uint32_t newSegmentsCount;
	////for (i = 0; i < 1; i++)
	for (i = 0; i < segments; i++)
	{
		startSegmentTime = GetTickCount();

		if (referenceDevice)
			startSegmentTime = GetTickCount();


		if (i > 0 && !referenceDevice)
		////if (!referenceDevice)
			dwWaitResult = WaitForSingleObject(deviceReceivers->receiverGates[deviceID], 10000000);

		FFT_BYTES(&data[currentSegmentIndex], fftBuffer, samplesCount, true, true);

		////SignalProcessingUtilities::CalculateMagnitudesAndPhasesForArray(fftBuffer, samplesCount);

		if (deviceReceivers->fftGraph)
		{
			////if (referenceDevice)
				deviceReceivers->fftGraph->SetData(fftBuffer, samplesCount, referenceDevice ? 0 : 1);
			////deviceReceivers->fftGraph->SetData(&data[currentSegmentIndex], segmentBufferLength, referenceDevice ? 0 : 1);

				deviceReceivers->fftGraph->SetDataWidth(samplesCount, referenceDevice ? 0 : 1);				
		}

		((SpectrumAnalyzer*)deviceReceivers->parent)->SetFFTInput(fftBuffer, frequencyRange, &data[currentSegmentIndex], samplesCount, deviceID);


		if (ReleaseSemaphore(deviceReceivers->receiversFinished[deviceID], 1, NULL)==0)
		{
			if (DebuggingUtilities::DEBUGGING)
			{
				DebuggingUtilities::DebugPrint("ReleaseSemaphore error: %d\n", GetLastError());
				
			}
		}

		if (DebuggingUtilities::DEBUGGING)
		{
			DebuggingUtilities::DebugPrint("ProcessData(): open deviceReceivers->receiversFinished[deviceID]\n");
		}

		if (referenceDevice)
		{
			if (DebuggingUtilities::DEBUGGING)
			{
				DebuggingUtilities::DebugPrint("referenceDevice WaitForMultipleObjects\n");
			}

			DWORD dwWaitResult = WaitForMultipleObjects(deviceReceivers->count, deviceReceivers->receiversFinished, true, 1000000);			

			switch (dwWaitResult)
			{
			case WAIT_OBJECT_0:
				DebuggingUtilities::DebugPrint("ProcessData(): deviceReceivers->receiversFinished open :-> ProcessReceiverData()\n");

				((SpectrumAnalyzer*)deviceReceivers->parent)->ProcessReceiverData(frequencyRange);
				////((SpectrumAnalyzer*)deviceReceivers->parent)->ProcessFFTInput(frequencyRange);

				deviceReceivers->ReleaseReceiverGates();
			case WAIT_TIMEOUT:
				break;
			default:
				break;
			}
		}

		currentSegmentIndex += DeviceReceiver::FFT_SEGMENT_BUFF_LENGTH;

		currentTime = GetTickCount();
		remainingTime = ((int32_t)receivedDuration[receivedCount - 1]) - (currentTime - startTime);
		segmentTime = (double)remainingTime / (segments - i);

		delay = (int32_t)(startSegmentTime + segmentTime) - currentTime;
		if (delay > 0)
			Sleep(delay);
		else
			i++;


		segmentDuration = currentTime - startSegmentTime;

		/*if (referenceDevice)
			segmentDuration = currentTime - startSegmentTime;

		remainingTime = ((int32_t)receivedDuration[receivedCount - 1]) - (GetTickCount() - startTime);

		if (segmentDuration > 0)
		{
		newSegmentsCount = i + (remainingTime / segmentDuration);

		if (newSegmentsCount < segments)
		segments = newSegmentsCount;
		}*/
	}

	/*////if (ReleaseSemaphore(receiverBufferDataAvailableGate, 1, NULL))
	{
		if (DebuggingUtilities::DEBUGGING)
			DebuggingUtilities::DebugPrint("ReleaseSemaphore error: %d\n", GetLastError());
	}

	if (DebuggingUtilities::DEBUGGING)
		DebuggingUtilities::DebugPrint("ProcessData() processed: open receiverBufferDataAvailableGate\n");
		*/

	if (!referenceDevice)
		dwWaitResult = WaitForSingleObject(deviceReceivers->receiverGates[deviceID], 10000000);

	DWORD totalTime = GetTickCount() - startTime;

	if (referenceDevice)
		int grc = 1;
	else
		int rtl = 2;
}


void ProcessReceivedDataThread(void *param)
{
	DeviceReceiver* deviceReceiver = (DeviceReceiver*) param;
	DeviceReceivers* deviceReceivers = (DeviceReceivers*) deviceReceiver->parent;

	while (true)
	{
		/*////
		if (deviceReceiver->referenceDevice)
		{
			if (ReleaseSemaphore(deviceReceivers->receiveDataGate1, 1, NULL))
			{
				if (DebuggingUtilities::DEBUGGING)
					DebuggingUtilities::DebugPrint("ReleaseSemaphore error: %d\n", GetLastError());
			}

			if (DebuggingUtilities::DEBUGGING)
				DebuggingUtilities::DebugPrint("ProcessReceivedDataThread(): open receiveDataGate1 :-> wait for rtlDataAvailableGate\n");
		}
		else
		{
			if (ReleaseSemaphore(deviceReceivers->receiveDataGate2, 1, NULL))
			{
				if (DebuggingUtilities::DEBUGGING)
					DebuggingUtilities::DebugPrint("ReleaseSemaphore error: %d\n", GetLastError());
			}

			if (DebuggingUtilities::DEBUGGING)
				DebuggingUtilities::DebugPrint("ProcessReceivedDataThread(): open receiveDataGate2:-> wait for rtlDataAvailableGate\n");
		}
		*/

		DWORD dwWaitResult = WaitForSingleObject(deviceReceiver->rtlDataAvailableGate, 1000000);
		////DWORD dwWaitResult = 0;		

		switch (dwWaitResult)
		{
		case WAIT_OBJECT_0:
			if (DebuggingUtilities::DEBUGGING)
				DebuggingUtilities::DebugPrint("ProcessReceivedDataThread(): rtlDataAvailableGate open:-> ProcessData()\n");

			if (deviceReceiver->receivedBuffer == NULL)
				deviceReceiver->receivedBuffer = new uint8_t[deviceReceiver->receivedLength];

			memcpy(deviceReceiver->receivedBuffer, deviceReceiver->receivedBufferPtr, deviceReceiver->receivedLength);

			deviceReceiver->WriteReceivedDataToBuffer(deviceReceiver->receivedBuffer, deviceReceiver->receivedLength);
			deviceReceiver->GetDelayAndPhaseShiftedData(deviceReceiver->receivedBuffer, deviceReceiver->receivedLength);
			deviceReceiver->ProcessData(deviceReceiver->receivedBuffer, deviceReceiver->receivedLength);
		case WAIT_TIMEOUT:
			break;
		default:
			break;
		}
	}
}


void DeviceReceiver::ReceiveData(uint8_t *buffer, long length)
{
	////receivedDuration[receivedCount++] = length;	

	DeviceReceivers* deviceReceivers = (DeviceReceivers*)parent;

	if (referenceDevice)
		deviceReceivers->receivedTime1[deviceReceivers->receivedCount1++] = GetTickCount();
	else
		deviceReceivers->receivedTime2[deviceReceivers->receivedCount2++] = GetTickCount();

	if (prevReceivedTime != 0)
		receivedDuration[receivedCount++] = GetTickCount() - prevReceivedTime;
	else
		receivedDuration[receivedCount++] = 1000;

	prevReceivedTime = GetTickCount();	

	
	/*////
	DWORD dwWaitResult1 = WaitForSingleObject(deviceReceivers->receiveDataGate1, 1000);
	DWORD dwWaitResult2 = WaitForSingleObject(deviceReceivers->receiveDataGate2, 1000);
	*/
	
	
	DWORD dwWaitResult1 = 0;
	DWORD dwWaitResult2 = 0;
	
	
	if (dwWaitResult1 == WAIT_OBJECT_0 && dwWaitResult2 == WAIT_OBJECT_0)
	{
		if (DebuggingUtilities::DEBUGGING)
			DebuggingUtilities::DebugPrint("ReceiveData(): receiveDataGate1 && receiveDataGate2 open:-> receivedBuffer = buffer\n");

		receivedBufferPtr = buffer;
		receivedLength = length;

		if (ReleaseSemaphore(rtlDataAvailableGate, 1, NULL)==0)
		{
			////DebuggingUtilities::DebugPrint("ReleaseSemaphore error: %d\n", GetLastError());
		}

		if (DebuggingUtilities::DEBUGGING)
			DebuggingUtilities::DebugPrint("ReceiveData(): open rtlDataAvailableGate :-> ReceiveData() finished\n");
	}
	else
	{
		if (DebuggingUtilities::DEBUGGING)
			DebuggingUtilities::DebugPrint("receiveDataGate closed\n");
	}
}

/*////void DeviceReceiver::ReceiveData2(uint8_t *buffer, long length)
{	
	receivedDuration[receivedCount++] = GetTickCount() - prevReceivedTime;
	prevReceivedTime = GetTickCount();


	////receivedDuration[receivedCount++] = length;

	////unsigned char *dataBuffer = new unsigned char[length];

	////unsigned char *dataBuffer = new unsigned char[FFT_SEGMENT_BUFF_LENGTH];
	////uint32_t length = this->CORRELATION_BUFF_LENGTH / 2;

	length = FFT_SEGMENT_BUFF_LENGTH;

	if (buffer2 == NULL)
		buffer2 = new uint8_t[length];

	if (fftBuffer == NULL)
		fftBuffer = new fftw_complex[length/2];


		*/

	/*////for (unsigned int k = 0; k < length; k += 2)
	{
		buffer2[k] = GetSampleByteAtIndex(k, length, GetTickCount());
		buffer2[k + 1] = GetSampleByteAtIndex(k, length, GetTickCount(), false);
		////dataBuffer[k * 2 + 1] = 127;
	}*/

		/*////
	

	receivedDuration[receivedCount++] = prevReceivedTime;

	if (DeviceReceivers::TEST_CORRELATION && referenceDevice)
	{
		for (int i = 0; i < length; i++)
			buffer[i] = ((float)rand() / RAND_MAX) * 255;
	}
		
	////buffer[0] = 255;

	*/

	/*////int divisor = length / 100;
	for (int i = 0; i < length; i++)
	{
		if (i%divisor == 0)		
		{
			buffer[i] = 255;			
		}
	}*/
	

	/*////
	if (!referenceDevice)
	{
		if (ReleaseSemaphore(startReceivingDataGate, 1, NULL))
		{
			////DebuggingUtilities::DebugPrint("ReleaseSemaphore error: %d\n", GetLastError());
		}
	}
	else
	{
		DWORD dwWaitResult = WaitForSingleObject(startReceivingDataGate, 1000000);

		switch (dwWaitResult)
		{
		case WAIT_OBJECT_0:			
			break;
		case WAIT_TIMEOUT:
			break;
		default:
			break;
		}
	}
	



	if (referenceDevice && DeviceReceivers::TEST_CORRELATION)
	{
		/*for (int i = 0; i < length; i++)
			buffer[i] = ((float)rand() / RAND_MAX) * 255;
			*/
/*////
		if (length == RECEIVE_BUFF_LENGTH)
			memcpy(transferDataBuffer, &buffer[10], length - 10);
			////memcpy(&transferDataBuffer[10], buffer, length - 10);
		else
		{
			int grc = 1;
		}
	}


	int32_t readStart = circularDataBuffer->writeStart;

	circularDataBuffer->WriteData(buffer, length);

	uint32_t segments = length / DeviceReceiver::FFT_SEGMENT_BUFF_LENGTH;

	uint32_t currentSegmentIndex = delayShift;

	////fftw_complex* fftBuffer = new fftw_complex[DeviceReceiver::FFT_SEGMENT_SAMPLE_COUNT];

	int i;

	DWORD dwWaitResult;
	DeviceReceivers* deviceReceivers = (DeviceReceivers*)parent;

	for (i = 0; i < segments; i++)
	{					
			if (i>0 && !referenceDevice)
				////if (!referenceDevice)
				dwWaitResult = WaitForSingleObject(deviceReceivers->receiverGates[deviceID], 10000000);

			////SignalProcessingUtilities::FFT_BYTES(&buffer[currentSegmentIndex], fftBuffer, DeviceReceiver::FFT_SEGMENT_SAMPLE_COUNT, false, true, !DeviceReceivers::RECEIVE_TEST_DATA);			

			////FFT_BYTES(buffer, fftBuffer, DeviceReceiver::FFT_SEGMENT_SAMPLE_COUNT, false, true, !DeviceReceivers::RECEIVE_TEST_DATA);
			////FFT_BYTES(buffer2, fftBuffer, DeviceReceiver::FFT_SEGMENT_SAMPLE_COUNT, false, true, !DeviceReceivers::RECEIVE_TEST_DATA);
			FFT_BYTES(buffer, fftBuffer, DeviceReceiver::FFT_SEGMENT_SAMPLE_COUNT, false, true);

			SignalProcessingUtilities::CalculateMagnitudesAndPhasesForArray(fftBuffer, DeviceReceiver::FFT_SEGMENT_SAMPLE_COUNT);			

			((SpectrumAnalyzer*) deviceReceivers->parent)->SetFFTInput(fftBuffer, frequencyRange, deviceID);
			
			////ReleaseSemaphore(setFFTGate2, deviceReceivers->count, NULL);
			ReleaseSemaphore(deviceReceivers->receiversFinished[deviceID], 1, NULL);

			if (referenceDevice)
			{
				WaitForMultipleObjects(deviceReceivers->count, deviceReceivers->receiversFinished, true, 1000000);
				((SpectrumAnalyzer*)deviceReceivers->parent)->ProcessFFTInput(frequencyRange);
				
				deviceReceivers->ReleaseReceiverGates();				
			}
			
			////fftSpectrumBuffers->SetFFTInput(fftSpectrumBufferIndex, fftBuffer, i, frequencyRange, i == 0);		
	}

	////fftSpectrumBuffers->ProcessFFTInput(fftSpectrumBufferIndex, &frequencyRange, useRatios);
	

	////delete[] fftBuffer;



	for (i = 0; i < devicesToSendClonedDataToCount; i++)	
		devicesToSendClonedDataTo[i]->ReceiveData(transferDataBuffer, length);


	if (ReleaseSemaphore(receiverBufferDataAvailableGate, 1, NULL))
	{
		////DebuggingUtilities::DebugPrint("ReleaseSemaphore error: %d\n", GetLastError());
	}
	
}
*/

void DataReceiver(unsigned char *buf, uint32_t len, void *ctx)
{
	struct DeviceReceiver* deviceReceiver = (DeviceReceiver*) ctx;

	deviceReceiver->ReceiveData(buf, len);
	////Sleep(1000);
}

void ReceivingDataThread(void *param)
{	
	DeviceReceiver* deviceReceiver = (DeviceReceiver*)param;

	if (!DeviceReceivers::RECEIVE_TEST_DATA)
	{
		DWORD dwWaitResult = WaitForSingleObject(((DeviceReceivers*)deviceReceiver->parent)->startReceivingDataGate, 1000000);

		switch (dwWaitResult)
		{
		case WAIT_OBJECT_0:
			if (!DeviceReceivers::TEST_CORRELATION || (DeviceReceivers::TEST_CORRELATION && deviceReceiver->referenceDevice))
				rtlsdr_read_async(deviceReceiver->device, DataReceiver, (void *)deviceReceiver, deviceReceiver->ASYNC_BUF_NUMBER, deviceReceiver->RECEIVE_BUFF_LENGTH);
			break;
		case WAIT_TIMEOUT:
			break;
		default:
			break;
		}	
	}
	else
	{
		DWORD dwWaitResult = WaitForSingleObject(((DeviceReceivers*)deviceReceiver->parent)->startReceivingDataGate, 1000000);

		while (DeviceReceivers::RECEIVE_TEST_DATA)
		{
			deviceReceiver->ReceiveTestData(deviceReceiver->RECEIVE_BUFF_LENGTH);			
		}
	}

	_endthread();
}

void DeviceReceiver::StartReceivingData()
{	
	if (referenceDevice || !DeviceReceivers::TEST_CORRELATION)
		receivingDataThreadHandle = (HANDLE)_beginthread(ReceivingDataThread, 0, this);
}


void DeviceReceiver::StartProcessingData()
{	
	processingDataThreadHandle = (HANDLE)_beginthread(ProcessReceivedDataThread, 0, this);
}

void DeviceReceiver::StopReceivingData()
{
	if (receivingDataThreadHandle != NULL)
	{
		rtlsdr_cancel_async(device);

		WaitForSingleObject(receivingDataThreadHandle, INFINITE);
		receivingDataThreadHandle = NULL;
	}
}

int DeviceReceiver::GetDelayAndPhaseShiftedData(uint8_t* dataBuffer, long dataBufferLength, float durationMilliSeconds, int durationBytes, bool async)
{		
		long readStartIndex;
		long length;
		int iValue, qValue, count = 0;

		char buffer[10];

		long seconds;

		if (!circularDataBuffer)
			return 0;

		////delayShift = 0;

		////DWORD dwWaitResult = WaitForSingleObject(receiverBufferDataAvailableGate, 10000);

		DWORD dwWaitResult = WaitForSingleObject(receiverBufferDataAvailableGate, 10000);

		////DWORD dwWaitResult = WAIT_OBJECT_0;

		switch (dwWaitResult)
		{
		case WAIT_OBJECT_0:
			if (DebuggingUtilities::DEBUGGING)
				DebuggingUtilities::DebugPrint("GetDelayAndPhaseShiftedData(): receiverBufferDataAvailableGate open:-> circularDataBuffer->ReadData()\n");

			if (durationMilliSeconds > 0)
			{
				length = (float)durationMilliSeconds / 1000 * SAMPLE_RATE;
			}
			else
				if (durationBytes > 0)
				{
					length = durationBytes;
				}
				else
					length = FFT_SEGMENT_BUFF_LENGTH;

			if (async)
				length = circularDataBuffer->ReadData(dataBuffer, length, delayShift, phaseShift);
			else
			{
				int n_read;

				rtlsdr_read_sync(device, dataBuffer, length, &n_read);

				return n_read;
			}


			/*////if (length > 0)
			{
				dataBufferLength = std::min(dataBufferLength, length);

				for (int j = 0; j < dataBufferLength; j++)
				{					
					dataBuffer[j] = dataBuffer[j] - 127;					
				}
			}*/

			return length;
			break;
		case WAIT_TIMEOUT:
			return 0;
			break;
		default:
			return 0;
			break;
		}
}



float DeviceReceiver::GetSampleAtIndex(long index, long length, long currentTime, bool realValue)
{
	////unsigned int sinFrequency = 16000;

	unsigned int sinFrequency = 4;
	float sinMultiplier = sinFrequency * 2 * M_PI;

	float value;

	double phase = 0;

	if (referenceDevice)
		////phase = -M_PI * (float) 2/3;
		////phase = -M_PI * (float)1 / 2;		
		////phase = M_PI * (float)1 / 2;
		phase = -M_PI;
		

	if (realValue)
		value = (float)sin(sinMultiplier * (float)index / length + phase);
	else
		value = (float)cos(sinMultiplier * (float)index / length + phase);

	////value /= 2;

	if (value>1.0)
		value = 1.0;

	if (value < -1.0)
		value = -1;

	////value *= (GetAlphaAtTime(currentTime) + 1);

	////value *= (GetAlphaAtTime(currentTime));


	/*////unsigned int alphaFrequency = 1;
	float alphaMultiplier = alphaFrequency * 2 * M_PI;

	value += ((float)sin(alphaMultiplier * (float)index / length)/10);

	////value *= ((float)sin(alphaMultiplier * (float)index / length) / 10);

	////value = (float)sin(alphaMultiplier * (float)index / length);
	*/


	if (value>1.0)
		value = 1.0;

	if (value < -1.0)
		value = -1;

	return value;
}

float DeviceReceiver::GetSampleByteAtIndex(long index, long length, long currentTime, bool realValue)
{
	return GetSampleAtIndex(index, length, currentTime, realValue) * 127 + 127;
}

void DeviceReceiver::GetTestData(uint8_t* buffer, uint32_t length)
{
	for (unsigned int k = 0; k < length; k += 2)
	{
		buffer[k] = GetSampleByteAtIndex(k, length, GetTickCount());
		buffer[k + 1] = GetSampleByteAtIndex(k, length, GetTickCount(), false);
		////dataBuffer[k * 2 + 1] = 127;
	}
}

void DeviceReceiver::ReceiveTestData(uint32_t length)
{
	DWORD startSegment = GetTickCount();

	DeviceReceivers* deviceReceivers = (DeviceReceivers*)parent;

	if (dataBuffer == NULL)
		dataBuffer = new uint8_t [length];

	GetTestData(dataBuffer, length);

	////unsigned char *dataBuffer = new unsigned char[FFT_SEGMENT_BUFF_LENGTH];
	////uint32_t length = this->CORRELATION_BUFF_LENGTH / 2;

	/*////for (unsigned int k = 0; k < length; k+=2)
	{
		dataBuffer[k] = GetSampleByteAtIndex(k, length, GetTickCount());
		dataBuffer[k + 1] = GetSampleByteAtIndex(k, length, GetTickCount(), false);
		////dataBuffer[k * 2 + 1] = 127;
	}
	*/

	////circularDataBuffer->WriteData(dataBuffer, FFT_SEGMENT_BUFF_LENGTH);

	////circularDataBuffer->WriteData(dataBuffer, length);

	////DWORD dwWaitResult1 = WaitForSingleObject(deviceReceivers->receiveDataGate1, 1000);
	////DWORD dwWaitResult2 = WaitForSingleObject(deviceReceivers->receiveDataGate2, 1000);

	DWORD dwWaitResult1 = 0;
	DWORD dwWaitResult2 = 0;

	if (dwWaitResult1 == WAIT_OBJECT_0 && dwWaitResult2 == WAIT_OBJECT_0)
	{
		if (DebuggingUtilities::DEBUGGING)
		{
			DebuggingUtilities::DebugPrint("ReceiveData(): receiveDataGate1 && receiveDataGate2 open:-> receivedBuffer = buffer\n");			
		}

		receivedBufferPtr = dataBuffer;
		receivedLength = length;

		if (ReleaseSemaphore(rtlDataAvailableGate, 1, NULL)==0)
		{
			if (DebuggingUtilities::DEBUGGING)
				DebuggingUtilities::DebugPrint("ReleaseSemaphore error: %d\n", GetLastError());
		}

		if (DebuggingUtilities::DEBUGGING)
		{
			DebuggingUtilities::DebugPrint("ReceiveDataTestData(): open rtlDataAvailableGate :-> ReceiveDataTestData() finished\n");
		}
	}
	else
	{
		if (DebuggingUtilities::DEBUGGING)
		{
			DebuggingUtilities::DebugPrint("receiveDataGate closed\n");
			
		}
	}

	////delete[] dataBuffer;
}

void DeviceReceiver::SetDelayShift(double value)
{
	////delayShift = value;
	////delayShift = 0;
	delayShift += value;
	////delayShift = 200;
}

void DeviceReceiver::SetPhaseShift(double value)
{
	////phaseShift += value;

	phaseShift = -3.14;
	////phaseShift = 0;
}

void DeviceReceiver::AddDeviceToSendClonedDataTo(DeviceReceiver *deviceReceiver)
{
	devicesToSendClonedDataTo[devicesToSendClonedDataToCount++] = deviceReceiver;	
}

void DeviceReceiver::GetDeviceCurrentFrequencyRange(uint32_t* startFrequency, uint32_t* endFrequency)
{
	*startFrequency = frequencyRange->lower;
	*endFrequency = frequencyRange->upper;	
}

DeviceReceiver::~DeviceReceiver()
{

	if (complexArray != NULL)
		fftw_free(complexArray);

	if (complexArray2 != NULL)
		fftw_free(complexArray2);

	delete circularDataBuffer;	

	if (dataBuffer != NULL)
		delete[] dataBuffer;
}

uint32_t DeviceReceiver::SAMPLE_RATE = 0;

long DeviceReceiver::RECEIVE_BUFF_LENGTH = 16384;

long DeviceReceiver::FFT_SEGMENT_BUFF_LENGTH = 16384;
long DeviceReceiver::CORRELATION_BUFF_LENGTH = FFT_SEGMENT_BUFF_LENGTH * 2;
long DeviceReceiver::FFT_SEGMENT_SAMPLE_COUNT = FFT_SEGMENT_BUFF_LENGTH / 2;
