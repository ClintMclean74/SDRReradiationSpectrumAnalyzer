#pragma once
#include <stdint.h>
#include "fftw3.h"

namespace SignalProcessingUtilities
{	
	const double M_PI = 3.14159265358979323846;

	void ShiftToZero(fftw_complex* data, uint32_t length);
	void FFT_BYTES(uint8_t *data, fftw_complex *fftData, int samples, bool inverse = false, bool inputComplex = true, bool rotate180 = false);
	void FFT_COMPLEX_ARRAY(fftw_complex* data, fftw_complex* fftData, int samples, bool inverse = false, bool rotate180 = false);
	uint8_t* CalculateMagnitudesAndPhasesForArray(uint8_t* array, long length);
	fftw_complex* CalculateMagnitudesAndPhasesForArray(fftw_complex* array, long length);
	void Rotate(uint8_t *data, long length, double angle);
	void ConjugateArray(fftw_complex* data, uint32_t length);
	void ComplexMultiplyArrays(fftw_complex* data1, fftw_complex* data2, fftw_complex* result, uint32_t length);
	uint32_t ClosestIntegerMultiple(long value, long multiplier);
	void DestroyFFTAllocations();
}