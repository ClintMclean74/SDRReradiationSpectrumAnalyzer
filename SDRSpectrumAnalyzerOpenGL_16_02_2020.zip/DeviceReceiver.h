#pragma once
#include "rtl-sdr.h"
#include "CircularDataBuffer.h"
#include "FrequencyRange.h"
#include "fftw3.h"

////extern HANDLE receiverBufferDataAvailableGate = NULL;

class DeviceReceiver
{	
	private:					
		CircularDataBuffer *circularDataBuffer = NULL;		
		HANDLE receivingDataThreadHandle = NULL;
		HANDLE processingDataThreadHandle = NULL;
		uint8_t *transferDataBuffer;		
		DeviceReceiver** devicesToSendClonedDataTo;
		uint8_t devicesToSendClonedDataToCount = 0;
		DWORD prevReceivedTime;
		DWORD* receivedDuration = new DWORD[10000];
		uint32_t receivedCount = 0;
		uint8_t deviceID;
		uint8_t* buffer2 = NULL;
		fftw_complex* fftBuffer = NULL;
		fftw_complex *complexArray = NULL;
		fftw_complex *complexArray2 = NULL;		

		uint8_t *dataBuffer = NULL;		
		
		float GetSampleAtIndex(long index, long length, long currentTime, bool realValue = true);
		float GetSampleByteAtIndex(long index, long length, long currentTime, bool realValue = true);		
				
	public:		
		rtlsdr_dev_t *device = NULL;
		static uint32_t SAMPLE_RATE;
		static long RECEIVE_BUFF_LENGTH;
		static long FFT_SEGMENT_BUFF_LENGTH;
		static long CORRELATION_BUFF_LENGTH;
		static long FFT_SEGMENT_SAMPLE_COUNT;
		short MAX_BUF_LEN_FACTOR = 1000;
		short ASYNC_BUF_NUMBER = 1;
		////long RTL_READ_FACTOR = 10;
		////long RTL_READ_FACTOR = 61;
		long RTL_READ_FACTOR = 122;
		FrequencyRange* frequencyRange;
		bool referenceDevice = false;		
		DWORD startTime = 0;
		int32_t delayShift = 0;
		double phaseShift = 0;

		////HANDLE receiveDataGate;
		HANDLE rtlDataAvailableGate;
		HANDLE receiverBufferDataAvailableGate;
		

		HANDLE setFFTGate1;
		HANDLE setFFTGate2;
		
		void* parent;

		uint8_t *receivedBuffer = NULL;
		uint32_t receivedLength = 0;

		uint8_t *receivedBufferPtr = NULL;
				
		DeviceReceiver(void* parent, long bufferSizeInMilliSeconds, uint32_t sampleRate, uint8_t ID);
		int InitializeDeviceReceiver(int dev_index);
		void SetFrequencyRange(FrequencyRange* frequencyRange);
		void FFT_BYTES(uint8_t *data, fftw_complex *fftData, int samples, bool inverse, bool inputComplex, bool rotate180 = false);
		void FFT_COMPLEX_ARRAY(fftw_complex* data, fftw_complex* fftData, int samples, bool inverse, bool rotate180);		
		void GenerateNoise(uint8_t state);
		void WriteReceivedDataToBuffer(uint8_t *data, uint32_t length);
		void ProcessData(uint8_t *data, uint32_t length);
		void ReceiveData(uint8_t* bufffer, long length);
		void ReceiveData2(uint8_t* buffer, long length);
		void GetTestData(uint8_t* buffer, uint32_t length);
		void ReceiveTestData(uint32_t length);
		int GetDelayAndPhaseShiftedData(uint8_t* dataBuffer, long dataBufferLength, float durationMilliSeconds = -1, int durationBytes = -1, bool async = true);
		void StartReceivingData();
		void StartProcessingData();
		void StopReceivingData();
		void SetDelayShift(double value);
		void SetPhaseShift(double value);
		void DeviceReceiver::AddDeviceToSendClonedDataTo(DeviceReceiver *deviceReceiver);
		void GetDeviceCurrentFrequencyRange(uint32_t* startFrequency, uint32_t* endFrequency);
	
		~DeviceReceiver();
};

////HANDLE DeviceReceiver::receiverBufferDataAvailableGate = NULL;

////int DeviceReceiver::count = 0;
////int DeviceReceiver::objectCount = 0;

typedef DeviceReceiver* DeviceReceiverPtr;

