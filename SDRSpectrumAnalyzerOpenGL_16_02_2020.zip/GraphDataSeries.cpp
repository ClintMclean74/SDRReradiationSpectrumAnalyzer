#define _ITERATOR_DEBUG_LEVEL 0
#include <math.h>
#include <algorithm>
#include <GL/glut.h>
#include "Graph.h"
#include "ArrayUtilities.h"

GraphDataSeries::GraphDataSeries(void* parentGraph)
{	
	this->parentGraph = parentGraph;

	bufferSize = BUFFER_START_SIZE;

	vertices = new VectorPtr[maxDepth];

	////for (int i = 0; i < bufferSize; i++)
		////vertices[i] = NULL;	

	for (int i = 0; i < maxDepth; i++)
		vertices[i] = new Vector[bufferSize];

	SetColor(1, 0, 0);
}

void GraphDataSeries::SetColor(float r, float g, float b)
{
	color.r = r;
	color.g = g;
	color.b = b;
}

uint32_t GraphDataSeries::SetData(uint8_t* data, uint32_t length, bool complex, double iOffset, double qOffset)
{
	double x, y, z;
	uint32_t j = 0;

	uint8_t inc;

	if (complex)
		inc = 2;
	else
		inc = 1;


	for (uint32_t i = 0; i < length; i += inc)
	{
		x = i;
				
		z = data[i] + iOffset;
		y = data[i + 1] + qOffset;

		AddPoint(j, y, z, j);

		j++;
	}

	currentZIndex++;

	if (currentZIndex >= maxDepth)
		currentZIndex = 0;

	return length;
}

uint32_t GraphDataSeries::SetData(double* data, uint32_t length, bool complex, double iOffset, double qOffset)
{	
	double x, y, z;
	uint32_t j = 0;

	uint8_t inc;

	if (complex)
		inc = 2;
	else
		inc = 1;


	for (uint32_t i = 0; i < length; i += inc)
	{
		x = i;

		z = data[i] + iOffset;
		y = data[i + 1] + qOffset;

		AddPoint(j, y, z, j);

		j++;
	}

	currentZIndex++;

	if (currentZIndex >= maxDepth)
		currentZIndex = 0;

	return length;
}

uint32_t GraphDataSeries::SetData(fftw_complex* data, uint32_t length, double iOffset, double qOffset)
{
	double x, y, z;
	double magnitude;

	uint32_t j = 0;

	for (uint32_t i = 0; i < length; i++)
	{
		x = i;

		z = data[i][0] + iOffset;
		y = data[i][1] + qOffset;

		if (y > 100)
		{
			int grc = 1;
		}

		/*////magnitude = sqrt(y*y + z*z);

		y = magnitude;
		z = 0;
		*/

		AddPoint(j, y, z, j);

		j++;
	}

	currentZIndex++;

	if (currentZIndex >= maxDepth)
		currentZIndex = 0;

	return length;
}

void GraphDataSeries::SetDataWidth(uint32_t width)
{
	dataWidth = width;
}

uint32_t GraphDataSeries::AddPoint(double x, double y, double z, int32_t index)
{		
	if (index >= bufferSize)
	{
		vertices = ArrayUtilities::ResizeArray(&vertices[currentZIndex], bufferSize, bufferSize*1.1);

		bufferSize *= 1.1;
	}	

	if (index == -1)
		index = verticesCount;

	////if (vertices[currentZIndex][index])
	{
		vertices[currentZIndex][index].x = x;
		vertices[currentZIndex][index].y = y;
		vertices[currentZIndex][index].z = z;
	}
	/*////else
	{
		vertices[index] = new Vector(x, y, z);
	}*/

	if (index >= verticesCount)
		verticesCount = index + 1;

	return verticesCount;
}

void GraphDataSeries::Draw(uint32_t startIndex, uint32_t endIndex, double scale, bool graphMagnitude)
{	
	if (endIndex == 0 || endIndex > verticesCount)
		endIndex = verticesCount;

	if (startIndex == endIndex)
		endIndex++;

	uint32_t length = endIndex - startIndex;

	if (endIndex - startIndex >= 2)
	{
		double yValue, zValue, magnitude;

		glColor3f(color.r, color.g, color.b);
		glLineWidth(2);
		

		uint32_t startPosX = 0;
		uint32_t endPosX = ((Graph *)parentGraph)->width;		
		uint32_t dataLength = endIndex - startIndex;

		double xInc = ((Graph *)parentGraph)->width / dataLength;
		float x = startPosX;

		if (scale == 1)
		{
			for (int32_t zIndex = 0; zIndex < currentZIndex; zIndex++)
			{
				glBegin(GL_LINE_STRIP);

				x = startPosX;

				for (int i = startIndex; i < endIndex; i++)
				{
					if (vertices[i])
					{
						yValue = vertices[zIndex][i].y;
						zValue = vertices[zIndex][i].z;

						magnitude = sqrt(yValue*yValue + zValue*zValue);

						yValue = magnitude;
						zValue = 0;

						glVertex3f(x, yValue, -zIndex);
					}

					x += xInc;
				}

				glEnd();
			}
		}
		else
		{
			for (uint32_t zIndex = 0; zIndex < maxDepth; zIndex++)
			{
				glBegin(GL_LINE_STRIP);

				for (int i = startIndex; i < endIndex; i++)
				{
					if (vertices[i])
					{
						yValue = vertices[zIndex][i].y * scale;
						zValue = vertices[zIndex][i].z * scale;

						glVertex3f(x, yValue, zValue);
					}

					x += xInc;
				}

				glEnd();
			}

		}

		
	}
}

MinMax GraphDataSeries::GetMinMax()
{
	double value;

	MinMax minMax;

	for (uint32_t zIndex = 0; zIndex < currentZIndex; zIndex++)
	{
		for (int i = 0; i < verticesCount; i++)
		{
			value = std::min(vertices[zIndex][i].y, vertices[zIndex][i].z);

			if (value < minMax.min || i == 0)
				minMax.min = value;

			value = std::max(vertices[zIndex][i].y, vertices[zIndex][i].z);

			if (value > minMax.max || i == 0)
				minMax.max = value;
		}
	}

	return minMax;
}

GraphDataSeries::~GraphDataSeries()
{
	delete vertices;
}

uint32_t GraphDataSeries::BUFFER_START_SIZE = 20000;