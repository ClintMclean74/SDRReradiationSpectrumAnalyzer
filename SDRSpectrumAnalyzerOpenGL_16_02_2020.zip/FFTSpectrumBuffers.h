#pragma once
#include "FFTSpectrumBuffer.h"

typedef FFTSpectrumBuffer* FFTSpectrumBuffersPtr;

class FFTSpectrumBuffers
{
	private:		
		unsigned int count;
		FFTSpectrumBuffersPtr* fftSpectrumBuffers;
		FFTSpectrumBuffer* fftDifferenceBuffer = NULL;

	public:
		FrequencyRange frequencyRange;

		FFTSpectrumBuffers(uint32_t lower, uint32_t upper, unsigned int fftSpectrumBufferCount, unsigned int deviceCount);
		uint32_t GetBinCountForFrequencyRange();
		void SetCalculateFFTDifferenceBuffer(bool value);
		FFTSpectrumBuffer* GetFFTSpectrumBuffer(unsigned int index);
		bool SetFFTInput(uint8_t index, fftw_complex* fftDeviceData, uint8_t* samples, uint32_t sampleCount, unsigned int deviceIndex, FrequencyRange* inputFrequencyRange, bool referenceDevice);
		bool ProcessFFTInput(unsigned int index, FrequencyRange* inputFrequencyRange, bool useRatios = false);
		uint32_t GetFFTData(double *dataBuffer, unsigned int dataBufferLength, int fftSpectrumBufferIndex, int startFrequency, int endFrequency, char dataMode);
		void CalculateFFTDifferenceBuffer(uint8_t index1, uint8_t index2);

		~FFTSpectrumBuffers();
};
