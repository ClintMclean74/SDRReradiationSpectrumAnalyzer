#pragma once
#include <stdint.h>
#include "fftw3.h"
#include "Vector.h"
#include "MinMax.h"
#include "Color.h"

class GraphDataSeries
{
	VectorPtr *vertices = NULL;	
	uint32_t bufferSize = BUFFER_START_SIZE;
	Color color;	
	void* parentGraph;
	uint32_t dataWidth;
	uint32_t maxDepth = 10;
	uint32_t currentZIndex = 0;

	public:
		static uint32_t GraphDataSeries::BUFFER_START_SIZE;

		uint32_t verticesCount = 0;
		GraphDataSeries(void* parentGraph);		
		void SetColor(float r, float g, float b);
		uint32_t SetData(uint8_t* data, uint32_t length, bool complex = true, double iOffset = 0, double qOffset = 0);
		uint32_t SetData(double* data, uint32_t length, bool complex = true, double iOffset = 0, double qOffset = 0);
		uint32_t SetData(fftw_complex* data, uint32_t length, double iOffset, double qOffset);
		void SetDataWidth(uint32_t width);
		uint32_t AddPoint(double x, double y, double z, int32_t index);		
		void Draw(uint32_t start, uint32_t end, double scale = 1, bool graphMagnitude = false);
		MinMax GetMinMax();
		~GraphDataSeries();
};


typedef GraphDataSeries* GraphDataSeriesPtr;