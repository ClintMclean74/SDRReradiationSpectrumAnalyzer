#pragma once
#include "rtl-sdr.h"
#include "DeviceReceiver.h"
#include "FFTSpectrumBuffers.h"
#include "fftw3.h"
#include "Graph.h"

typedef DeviceReceiver* DeviceReceiversPtr;

typedef fftw_complex* fftw_complex_ptr;


class DeviceReceivers
{
	private:		
		DeviceReceiversPtr* deviceReceivers;

		uint8_t* referenceDataBuffer = NULL;
		uint8_t* dataBuffer = NULL;

		fftw_complex_ptr* fftBuffers = NULL;
		fftw_complex* convolutionFFT;
		fftw_complex* convolution;

		int32_t correlationBufferSamples;
		int32_t correlationBufferLengthZeroPadded;	

		int32_t* avgDelays = new int32_t[100000];
		int32_t avgDelaysCount = 0;

		uint32_t synchronizedCount = 0;

	public:
		uint8_t count = 0;
		uint8_t initializedDevices = 0;
		FrequencyRange frequencyRange;
		static const bool RECEIVE_TEST_DATA = false;
		static const bool TEST_CORRELATION = false;
		static HANDLE startReceivingDataGate;
		HANDLE receiveDataGate1 = NULL;
		HANDLE receiveDataGate2 = NULL;
		HANDLE* receiverGates = NULL;
		HANDLE* receiversFinished = NULL;
		void* parent;
		fftw_plan complexArrayFFTPlan = NULL, complexArrayFFTPlan2 = NULL, complexArrayCorrelationFFTPlan = NULL;
		Graph* dataGraph = NULL;
		Graph* fftGraph = NULL;
		Graph* correlationGraph = NULL;
		
		DWORD* receivedTime1 = new DWORD[100000];
		uint32_t receivedCount1 = 0;

		DWORD* receivedTime2 = new DWORD[100000];
		uint32_t receivedCount2 = 0;

		DeviceReceivers(void* parent, long bufferSizeInMilliSeconds, uint32_t sampleRate);
		void InitializeDevices();
		void SetCurrentCenterFrequency(uint32_t centerFrequency);
		void StartReceivingData();
		bool Synchronized();
		uint32_t Synchronize(uint8_t* referenceDataBuffer, uint8_t* dataBuffer);
		uint32_t GetDataForDevice(double *dataBuffer, uint8_t deviceIndex);
		uint32_t GetDataForDevice(uint8_t *dataBuffer, uint8_t deviceIndex);
		void ReleaseReceiverGates();				
		void TransferDataToFFTSpectrumBuffer(FFTSpectrumBuffers* fftSpectrumBuffers, uint8_t fftSpectrumBufferIndex, bool useRatios = false);
		void GetDeviceCurrentFrequencyRange(uint32_t deviceIndex, uint32_t* startFrequency, uint32_t* endFrequency);
		
		~DeviceReceivers();
};