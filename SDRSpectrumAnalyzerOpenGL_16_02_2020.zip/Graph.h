#pragma once
#define _ITERATOR_DEBUG_LEVEL 0
#include <stdint.h>
#include <GL/glut.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_inverse.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "fftw3.h"
#include "Vector.h"
#include "MinMax.h"
#include "GraphDataSeries.h"

class Graph
{		
	GraphDataSeriesPtr* dataSeries;
	uint8_t dataSeriesCount = 2;

	uint32_t startIndex = 0;
	uint32_t endIndex = 0;
	Color axisColor;
	Color selectedAreaColor;

	uint32_t points;

	double dataScale = 1;
	
	GLfloat axisLineWidth;
	GLfloat selectedStart = 0, selectedEnd = 0;
	bool paused = false;
	
	glm::mat4* matrix;

	double xRot = 0;	
	double yRot = 0;
	double zRot = 0;

	uint32_t dataWidth;

	public:
		Vector pos;
		double width;
		double height;
		char text[255];

		Graph();
		void CalculateScale();
		void SetSize(double width, double height);
		void SetPos(double x, double y, double z);
		void SetRotation(double xRot, double yRot, double zRot);
		uint32_t SetData(uint8_t* data, uint32_t length, uint8_t seriesIndex, bool complex = true, double iOffset = 0, double qOffset = 0);
		uint32_t SetData(double* data, uint32_t length, uint8_t seriesIndex, bool complex = true, double iOffset = 0, double qOffset = 0);
		uint32_t SetData(fftw_complex* data, uint32_t length, uint8_t seriesIndex, double iOffset = 0, double qOffset = 0);
		void SetDataWidth(uint32_t width, uint8_t seriesIndex);
		void ZoomOut();
		glm::vec4 PointOnGraph(float x, float y, float z);
		void SetSelectedGraphRange(uint32_t start, uint32_t end);
		void SetGraphRange(uint32_t start, uint32_t end);

		void SetText(char *string, uint32_t length);
		void DrawText(char *string, float x, float y, float z);
		void Draw();
		void DrawTransparencies();
		void TogglePause();

		~Graph();
};

typedef Graph* GraphPtr;
