#include <GL/glut.h>
#include "Graphs.h"


Graphs::Graphs()
{
	bufferSize = 3;
	graphs = new GraphPtr[bufferSize];	
}

uint32_t Graphs::AddGraph(Graph* graph)
{
	graphs[graphCount++] = graph;

	return graphCount;
}

void Graphs::Draw()
{
	for (int i = 0; i < graphCount; i++)
		graphs[i]->Draw();
}

SelectedGraph Graphs::GetSelectedGraph(float x, float y, float z)
{
	SelectedGraph selectedGraph;

	glm::vec4 vector;

	for (int i = 0; i < graphCount; i++)
	{
		vector = graphs[i]->PointOnGraph(x, y, z);

		if (vector.x != -1 && vector.y != -1 && vector.z != -1)
		{
			selectedGraph.graph = graphs[i];
			selectedGraph.point = vector;
		}
	}

	return selectedGraph;
}

Graphs::~Graphs()
{

}