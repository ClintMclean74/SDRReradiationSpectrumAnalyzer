#include <GL/glut.h>
#include <time.h>
#include "NearFarDataAnalyzer.h"
#include "Graphs.h"
#include "SignalProcessingUtilities.h"
#include "DebuggingUtilities.h"

NearFarDataAnalyzer* nearFarDataAnalyzer;

Graphs* graphs = new Graphs();
Graph *dataGraph, *fftGraph, *correlationGraph;
SelectedGraph selectedGraphStart;
SelectedGraph selectedGraphEnd;
Vector pos;
double xRot = 0;
double yRot = 0;

double fov = 15;

int prevX = -1;
int prevY = -1;

int currentButton = 0;

bool viewChanged = true;

bool ctrl = false;
bool shift = false;
bool alt = false;

Vector Get3DPoint(int screenX, int screenY)
{
	Vector vector;

	GLint viewport[4];
	GLdouble modelview[16];
	GLdouble projection[16];

	glGetIntegerv(GL_VIEWPORT, viewport);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	glGetDoublev(GL_MODELVIEW_MATRIX, modelview);
	glGetDoublev(GL_PROJECTION_MATRIX, projection);

	GLfloat z_cursor;
	
	screenY = viewport[3] - screenY;

	// Get the z value for the screen coordinate
	glReadPixels(screenX, screenY, 1, 1, GL_DEPTH_COMPONENT, GL_FLOAT, &z_cursor);

	// get the 3D coordinate
	gluUnProject(screenX, screenY, z_cursor, modelview, projection, viewport, &vector.x, &vector.y, &vector.z);

	return vector;
}

void DrawText(char *string, float x, float y, float z)
{
	char *c;
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glTranslatef(x, y, z);
	glScalef(1, 0.75, 1.0);
	
	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
	
	glDisable(GL_DEPTH_TEST);

	for (c = string; *c != '\0'; c++)
	{
		glutStrokeCharacter(GLUT_STROKE_ROMAN, *c);
	}

	glEnable(GL_DEPTH_TEST);
}

void display(void)
{
	////if (viewChanged)
	{
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		////glOrtho(dataGraph->pos.x - 10, dataGraph->pos.x + dataGraph->width + 10, correlationGraph->pos.y - correlationGraph->height, dataGraph->pos.y + dataGraph->height, 1.0, 10000);
		////gluPerspective(90, glutGet(GLUT_WINDOW_HEIGHT)/glutGet(GLUT_WINDOW_WIDTH), 0, 1000);

		gluPerspective(fov, (GLdouble) glutGet(GLUT_WINDOW_HEIGHT) / glutGet(GLUT_WINDOW_WIDTH), 1.0, 10000.0);

		viewChanged = false;
	}
	
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	uint32_t dataLength;

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();	

	glTranslatef(pos.x, pos.y, pos.z);

	glRotatef(xRot, 1, 0, 0);
	glRotatef(yRot, 0, 1, 0);
	////glRotatef(-90, 0, 1, 0);

	dataGraph->Draw();
	fftGraph->Draw();
	correlationGraph->Draw();

	dataGraph->DrawTransparencies();
	fftGraph->DrawTransparencies();
	correlationGraph->DrawTransparencies();

	glutSwapBuffers();

	glutPostRedisplay();
}

void MouseButtons(int button, int state, int x, int y)
{
	currentButton = button;

	// Wheel reports as button 3(scroll up) and button 4(scroll down)
	if (button == 3 || button == 4) // It's a wheel event
	{
		// Each wheel event reports like a button click, GLUT_DOWN then GLUT_UP
		if (state == GLUT_UP) return; // Disregard redundant GLUT_UP events

		if (button == 3)
			fov--;
		else
			fov++;

		DebuggingUtilities::DebugPrint("Scroll %s At %d %d\n", (button == 3) ? "Up" : "Down", x, y);
	}
	
	if (button == GLUT_LEFT_BUTTON)
	{
		prevX = x;
		prevY = y;

		if (state == GLUT_DOWN)
		{		
			Vector vector = Get3DPoint(x, y);

			selectedGraphStart = graphs->GetSelectedGraph(vector.x, vector.y, vector.z);
		}
		else
			if (state == GLUT_UP)
			{
				Vector vector = Get3DPoint(x, y);

				selectedGraphEnd = graphs->GetSelectedGraph(vector.x, vector.y, vector.z);

				if (selectedGraphEnd.graph != NULL)
				{
					if (selectedGraphEnd.graph == selectedGraphStart.graph)
					{
						if (selectedGraphEnd.point.x < 0)
							selectedGraphEnd.point.x = 0;

						if (selectedGraphEnd.point.x > selectedGraphStart.point.x)
							selectedGraphEnd.graph->SetGraphRange(selectedGraphStart.point.x, selectedGraphEnd.point.x);
						else
							selectedGraphEnd.graph->SetGraphRange(selectedGraphEnd.point.x, selectedGraphStart.point.x);
					}

					selectedGraphEnd.graph->SetSelectedGraphRange(0, 0);
				}

				if (selectedGraphStart.graph != NULL)
					selectedGraphStart.graph->SetSelectedGraphRange(0, 0);
			}
	}
	else		
		if (button == GLUT_RIGHT_BUTTON)
		{
			Vector vector = Get3DPoint(x, y);

			selectedGraphStart = graphs->GetSelectedGraph(vector.x, vector.y, vector.z);

			if (selectedGraphStart.graph != NULL )
				selectedGraphStart.graph->ZoomOut();
		}
}

void MouseMotion(int x, int y)
{
	if (currentButton == GLUT_LEFT_BUTTON)
	{
		Vector vector = Get3DPoint(x, y);

		selectedGraphEnd = graphs->GetSelectedGraph(vector.x, vector.y, vector.z);

		if (selectedGraphEnd.graph != NULL && selectedGraphEnd.graph == selectedGraphStart.graph)
		{
			if (selectedGraphEnd.point.x < 0)
				selectedGraphEnd.point.x = 0;

			if (selectedGraphEnd.point.x > selectedGraphStart.point.x)
				selectedGraphEnd.graph->SetSelectedGraphRange(selectedGraphStart.point.x, selectedGraphEnd.point.x);
			else
				selectedGraphEnd.graph->SetSelectedGraphRange(selectedGraphEnd.point.x, selectedGraphStart.point.x);
		}
	}
	
	prevX = x;
	prevY = y;
}


void PassiveMouseMotion(int x, int y)
{
	ctrl = false;
	shift = false;
	alt = false;

	int mod = glutGetModifiers();

	if (mod != 0)
	{
		switch (mod)
		{
		case 1:
			shift = true;
			break;

		case 2:
			ctrl = true;
			break;

		case 4:
			alt = true;			
			break;

			mod = 0;
		}
	}

	if (ctrl)
	{
		xRot += y - prevY;
		yRot += x - prevX;
	}
	if (shift)
	{
		pos.x += x - prevX;
		pos.y -= y - prevY;
	}	

	prevX = x;
	prevY = y;
}

void Keyboard(unsigned char key, int x, int y)
{	
	switch (key)
	{
		case (' '):
			dataGraph->TogglePause();
			fftGraph->TogglePause();
			correlationGraph->TogglePause();
		break;
		default:
		break;		
	}
}

void InitializeGL(void)
{		
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutCreateWindow("SDR Spectrum Analyzer");
	glutDisplayFunc(display);	

	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	glClearColor(0.0, 0.0, 0.0, 0.0);
	
	glEnable(GL_DEPTH_TEST);
	
	glMatrixMode(GL_MODELVIEW);
	gluLookAt(0.0, 0.0, 100.0,  /* eye is at (0,0,5) */
		0.0, 0.0, 0.0,      /* center is at (0,0,0) */
		0.0, 1.0, 0.);      /* up is in positive Y direction */

	glutMouseFunc(MouseButtons);
	glutMotionFunc(MouseMotion);
	glutPassiveMotionFunc(PassiveMouseMotion);
	glutKeyboardFunc(Keyboard);
}

void ProcessSequenceFinished()
{
	nearFarDataAnalyzer->ProcessSequenceFinished();
}

int InitializeNearFarSpectrumAnalyzerAndGraphs()
{
	nearFarDataAnalyzer = new NearFarDataAnalyzer();
	int deviceCount = nearFarDataAnalyzer->InitializeNearFarDataAnalyzer(20000, 1000000, 96000000, 97000000);
	nearFarDataAnalyzer->spectrumAnalyzer.SetSequenceFinishedFunction(&ProcessSequenceFinished);

	pos.x = -500;
	pos.z = -9000;

	graphs = new Graphs();

	dataGraph = new Graph();
	dataGraph->SetSize(1000, 700);
	dataGraph->SetPos(0, 700, 0);

	nearFarDataAnalyzer->spectrumAnalyzer.deviceReceivers->dataGraph = dataGraph;
	
	graphs->AddGraph(dataGraph);


	fftGraph = new Graph();
	fftGraph->SetSize(1000, 700);
	fftGraph->SetPos(1000, 700, 0);

	nearFarDataAnalyzer->spectrumAnalyzer.deviceReceivers->fftGraph = fftGraph;

	graphs->AddGraph(fftGraph);



	correlationGraph = new Graph();
	correlationGraph->SetSize(1000, 700);
	correlationGraph->SetPos(0, -700, 0);
	correlationGraph->SetRotation(-90, 0, 0);

	nearFarDataAnalyzer->spectrumAnalyzer.deviceReceivers->correlationGraph = correlationGraph;

	graphs->AddGraph(correlationGraph);

	return 1;
}

void Initialize(void)
{	
	InitializeNearFarSpectrumAnalyzerAndGraphs();
	InitializeGL();
}

int main(int argc, char **argv)
{	
	glutInit(&argc, argv);

	Initialize();

	glutMainLoop();

	return 0;
}

void Close()
{
	delete nearFarDataAnalyzer;
	delete graphs;
}
