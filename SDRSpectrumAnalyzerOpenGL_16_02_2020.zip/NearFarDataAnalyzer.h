#pragma once
#include "SpectrumAnalyzer.h"
#include "FrequencyRanges.h"

class NearFarDataAnalyzer
{	
	private:
		FrequencyRange scanningRange;
		bool dataIsNear = true;		
		DWORD dataIsNearTimeStamp = 0; 
		bool processing = false;
		bool automatedDetection = true;
		static const uint32_t INACTIVE_DURATION_UNDETERMINED = 10000;
		static const uint32_t INACTIVE_DURATION_FAR = 60000;
		HANDLE processingThreadHandle;		
		FrequencyRanges* leaderboardFrequencyRanges;

	public:
		SpectrumAnalyzer spectrumAnalyzer;		

		NearFarDataAnalyzer();
		uint8_t InitializeNearFarDataAnalyzer(uint32_t bufferSizeInMilliSeconds, uint32_t sampleRate, uint32_t minStartFrequency, uint32_t maxEndFrequency);
		void ProcessSequenceFinished();
		void SetMode(uint8_t value);
		void Process();
		void StartProcessingThread();
		uint32_t GetNearFFTData(double *dataBuffer, uint32_t dataBufferLength, uint32_t startFrequency, uint32_t endFrequency, uint8_t dataMode);
		double GetNearFFTStrengthForRange(uint32_t startFrequency, uint32_t endFrequency, uint8_t dataMode);
		~NearFarDataAnalyzer();
};

////static const DebuggingUtilities::DEBUGGING = false;