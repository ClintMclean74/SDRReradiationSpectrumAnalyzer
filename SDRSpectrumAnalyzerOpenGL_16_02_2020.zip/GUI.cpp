#include "Graphs.h"

class GUI
{
	private:
		Graphs* graphs = new Graphs();
		Graph *dataGraph, *correlationGraph;
		SelectedGraph selectedGraphStart;
		SelectedGraph selectedGraphEnd;

};