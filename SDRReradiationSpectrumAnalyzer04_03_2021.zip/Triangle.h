#pragma once
#include "MathUtilities.h"

class Triangle
{
	public:	
		GLuint i1 = 0;
		GLuint i2 = 0;
		GLuint i3 = 0;

		Triangle()
		{			
		}		
};

/*////Vector Triangle::CalculateNormal()
{
	MathUtilities::CalcNormal();
}*/