#pragma once

class GraphicsUtilities
{	
	public:
		static float fontScale;
		static void DrawText(char *string, float x, float y, float z, float height = 1, float angle = 0);
};
