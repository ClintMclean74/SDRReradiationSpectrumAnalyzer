#pragma once

class Color
{
	public:
		float r;
		float g;
		float b;
		float a;

		Color()
		{
			r = g = b = a = 1;
		}
};