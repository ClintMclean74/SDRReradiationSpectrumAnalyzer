#pragma once
#include <GL/glut.h>

struct VertexXYZColor
{
	GLfloat m_Pos;
	GLfloat m_Color;
};


